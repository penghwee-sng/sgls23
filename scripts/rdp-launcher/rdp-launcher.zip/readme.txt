Remote Desktop Session Launcher

1) Right click rdp-launcher.ps1 and run with Powershell.
2) Select the machine you want to go in.
3) Press Launch button to open RDP session.

Happy hunting!